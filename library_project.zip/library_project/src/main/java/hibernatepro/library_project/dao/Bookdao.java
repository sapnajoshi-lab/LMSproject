package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.Book;
import java.util.List;

public interface Bookdao {
    void saveBook(Book book);
    Book getBookById(int id);
    List<Book> getAllBooks();
    void updateBook(Book book);
    void deleteBookById(int id);
	List<Book> searchBooks(String searchQuery);
}