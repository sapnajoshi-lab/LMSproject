package hibernatepro.library_project.entity;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import jakarta.persistence.*;

@Entity
@Table(name = "Categories")
public class Category {

    @Id // Indicates primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment
    @Column(name = "category_id")
    private int category_id;

    @NotNull(message = "Category name cannot be null") // Ensure categoryName is not null
    @Size(min = 3, max = 50, message = "Category name must be between 3 and 50 characters")
    @Column(name = "category_name", nullable = false, length = 50) // DB column details
    private String category_name;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Book> books;

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public Category(int category_id,
			@NotNull(message = "Category name cannot be null") @Size(min = 3, max = 50, message = "Category name must be between 3 and 50 characters") String category_name,
			List<Book> books) {
		super();
		this.category_id = category_id;
		this.category_name = category_name;
		this.books = books;
	}

	public Category() {
	}

	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", category_name=" + category_name + ", books=" + books + "]";
	}
    
    
}
