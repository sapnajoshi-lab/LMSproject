package hibernatepro.library_project.entity;

import java.util.Date;
import java.util.List;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import jakarta.persistence.*;

@Entity
@Table(name = "Member")
public class Members {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id")
    private Long member_id;

    @Column(length = 20, nullable = false)
    @NotNull(message = "Name is required")
    @Size(min = 2, max = 20)
    private String name;

    @Column(length = 30, nullable = false, unique = true)
    @NotNull(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    @Column(length = 10, nullable = false)
    @NotNull(message = "Password is required")
    private String password;

    @Column(length = 30, nullable = false, unique = true)
    @NotNull(message = "Phone number is required")
    @Pattern(regexp = "[6789]{1}[0-9]{9}", message = "Enter a proper phone number")
    private String phoneNo;

    @NotNull(message = "Membership date cannot be null")
    @Past(message = "Membership date must be in the past")
    @Temporal(TemporalType.DATE)
    private Date membershipdate;

    @ManyToOne
    @JoinColumn(name = "librarian_id")
    private Librarian librarian;

    @OneToMany(mappedBy = "Member", cascade = CascadeType.ALL)
    private List<MemberReport> reports;

    @ManyToMany
    @JoinTable(
        name = "borrowed_books",
        joinColumns = @JoinColumn(name = "member_id"),
        inverseJoinColumns = @JoinColumn(name = "book_id")
    )
    private List<Book> borrowedBooks;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @OneToOne
    @JoinColumn(name = "id")
    private Authsystem authentication;

	public Long getMember_id() {
		return member_id;
	}

	public void setMember_id(Long member_id) {
		this.member_id = member_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Date getMembershipdate() {
		return membershipdate;
	}

	public void setMembershipdate(Date membershipdate) {
		this.membershipdate = membershipdate;
	}

	public Librarian getLibrarian() {
		return librarian;
	}

	public void setLibrarian(Librarian librarian) {
		this.librarian = librarian;
	}

	public List<MemberReport> getReports() {
		return reports;
	}

	public void setReports(List<MemberReport> reports) {
		this.reports = reports;
	}

	public List<Book> getBorrowedBooks() {
		return borrowedBooks;
	}

	public void setBorrowedBooks(List<Book> borrowedBooks) {
		this.borrowedBooks = borrowedBooks;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Authsystem getAuthentication() {
		return authentication;
	}

	public void setAuthentication(Authsystem authentication) {
		this.authentication = authentication;
	}

	public Members(Long member_id, @NotNull(message = "Name is required") @Size(min = 2, max = 20) String name,
			@NotNull(message = "Email is required") @Email(message = "Email should be valid") String email,
			@NotNull(message = "Password is required") String password,
			@NotNull(message = "Phone number is required") @Pattern(regexp = "[6789]{1}[0-9]{9}", message = "Enter a proper phone number") String phoneNo,
			@NotNull(message = "Membership date cannot be null") @Past(message = "Membership date must be in the past") Date membershipdate,
			Librarian librarian, List<MemberReport> reports, List<Book> borrowedBooks, Category category,
			Authsystem authentication) {
		super();
		this.member_id = member_id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.phoneNo = phoneNo;
		this.membershipdate = membershipdate;
		this.librarian = librarian;
		this.reports = reports;
		this.borrowedBooks = borrowedBooks;
		this.category = category;
		this.authentication = authentication;
	}

	public Members() {
	}

	@Override
	public String toString() {
		return "Members [member_id=" + member_id + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", phoneNo=" + phoneNo + ", membershipdate=" + membershipdate + ", librarian=" + librarian
				+ ", reports=" + reports + ", borrowedBooks=" + borrowedBooks + ", category=" + category
				+ ", authentication=" + authentication + "]";
	}
    
    
}