package hibernatepro.library_project.entity;

import jakarta.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
@Table(name = "Librarians")
public class Librarian {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "librarian_id")
    private Long librarian_id;

    @Column(length = 20, nullable = false)
    @NotNull(message = "Name is required")
    @Size(min = 2, max = 20, message = "Name must be between 2 and 20 characters")
    private String name;

    @Column(length = 30, nullable = false, unique = true)
    @NotNull(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    @Column(length = 60, nullable = false)
    @NotNull(message = "Password is required")
    private String password;

    @OneToMany(mappedBy = "Librarians", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<MemberReport> memberReports;

    @OneToMany(mappedBy = "Librarians", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Book> books;

    @OneToOne(mappedBy = "Librarians", cascade = CascadeType.ALL, orphanRemoval = true)
    private Authsystem authentication;

	public Long getLibrarian_id() {
		return librarian_id;
	}

	public void setLibrarian_id(Long librarian_id) {
		this.librarian_id = librarian_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<MemberReport> getMemberReports() {
		return memberReports;
	}

	public void setMemberReports(List<MemberReport> memberReports) {
		this.memberReports = memberReports;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public Authsystem getAuthentication() {
		return authentication;
	}

	public void setAuthentication(Authsystem authentication) {
		this.authentication = authentication;
	}

	public Librarian(Long librarian_id,
			@NotNull(message = "Name is required") @Size(min = 2, max = 20, message = "Name must be between 2 and 20 characters") String name,
			@NotNull(message = "Email is required") @Email(message = "Email should be valid") String email,
			@NotNull(message = "Password is required") String password, List<MemberReport> memberReports,
			List<Book> books, Authsystem authentication) {
		super();
		this.librarian_id = librarian_id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.memberReports = memberReports;
		this.books = books;
		this.authentication = authentication;
	}

	public Librarian() {
	}

	@Override
	public String toString() {
		return "Librarian [librarian_id=" + librarian_id + ", name=" + name + ", email=" + email + ", password="
				+ password + ", memberReports=" + memberReports + ", books=" + books + ", authentication="
				+ authentication + "]";
	}
    
    
}