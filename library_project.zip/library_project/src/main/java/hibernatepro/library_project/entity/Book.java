package hibernatepro.library_project.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import jakarta.persistence.*;


@Entity
@Table(name = "Bookinfo")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int book_id;

    @NotNull(message = "Title cannot be null")
    @Size(min = 3, max = 100, message = "Title should be between 3 and 100 characters")
    private String title;

    @NotNull(message = "Author cannot be null")
    @Size(min = 3, max = 50, message = "Author name should be between 3 and 50 characters")
    private String author;

    @NotNull(message = "Year of publication cannot be null")
    @Min(value = 1000, message = "Year of publication must be greater than or equal to 1000")
    @Max(value = 2025, message = "Year of publication cannot be in the future")
    private int yearOfPublication;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

	public int getBook_id() {
		return book_id;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getYearOfPublication() {
		return yearOfPublication;
	}

	public void setYearOfPublication(int yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Book(int book_id,
			@NotNull(message = "Title cannot be null") @Size(min = 3, max = 100, message = "Title should be between 3 and 100 characters") String title,
			@NotNull(message = "Author cannot be null") @Size(min = 3, max = 50, message = "Author name should be between 3 and 50 characters") String author,
			@NotNull(message = "Year of publication cannot be null") @Min(value = 1000, message = "Year of publication must be greater than or equal to 1000") @Max(value = 2025, message = "Year of publication cannot be in the future") int yearOfPublication,
			Category category) {
		super();
		this.book_id = book_id;
		this.title = title;
		this.author = author;
		this.yearOfPublication = yearOfPublication;
		this.category = category;
	}

	public Book() {
	}

	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", title=" + title + ", author=" + author + ", yearOfPublication="
				+ yearOfPublication + ", category=" + category + "]";
	}

	public void setCategory(String category2) {
		// TODO Auto-generated method stub
		
	}
    
    
}