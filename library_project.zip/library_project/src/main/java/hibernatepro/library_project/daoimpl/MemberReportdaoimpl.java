package hibernatepro.library_project.daoimpl;

import hibernatepro.library_project.dao.MemberReportdao;
import hibernatepro.library_project.entity.MemberReport;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class MemberReportdaoimpl implements MemberReportdao {

    private SessionFactory sessionFactory;

    // Constructor to initialize SessionFactory
    public MemberReportdaoimpl() {
        sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(MemberReport.class)
                .buildSessionFactory();
    }

    @Override
    public void saveMemberReport(MemberReport memberReport) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(memberReport);
            transaction.commit();
            System.out.println("MemberReport saved successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public MemberReport getMemberReportById(int id) {
        MemberReport memberReport = null;
        try (Session session = sessionFactory.openSession()) {
            memberReport = session.get(MemberReport.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return memberReport;
    }

    @Override
    public List<MemberReport> getAllMemberReports() {
        List<MemberReport> memberReports = null;
        try (Session session = sessionFactory.openSession()) {
            memberReports = session.createQuery("from MemberReport", MemberReport.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return memberReports;
    }

    @Override
    public void updateMemberReport(MemberReport memberReport) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(memberReport);
            transaction.commit();
            System.out.println("MemberReport updated successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMemberReportById(int id) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            MemberReport memberReport = session.get(MemberReport.class, id);
            if (memberReport != null) {
                session.delete(memberReport);
                System.out.println("MemberReport deleted successfully!");
            } else {
                System.out.println("MemberReport not found with id: " + id);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
