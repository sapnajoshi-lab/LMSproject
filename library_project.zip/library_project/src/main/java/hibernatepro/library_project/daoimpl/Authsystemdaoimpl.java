package hibernatepro.library_project.daoimpl;

import hibernatepro.library_project.dao.Authsystemdao;
import hibernatepro.library_project.entity.Authsystem;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Authsystemdaoimpl implements Authsystemdao {

    private SessionFactory sessionFactory;

    // Constructor to initialize SessionFactory
    public Authsystemdaoimpl() {
        sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Authsystem.class)
                .buildSessionFactory();
    }

    @Override
    public void saveAuthsystem(Authsystem authsystem) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(authsystem);
            transaction.commit();
            System.out.println("Authsystem saved successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Authsystem getAuthsystemById(int logid) {
        Authsystem authsystem = null;
        try (Session session = sessionFactory.openSession()) {
            authsystem = session.get(Authsystem.class, logid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return authsystem;
    }

    @Override
    public List<Authsystem> getAllAuthsystems() {
        List<Authsystem> authsystems = null;
        try (Session session = sessionFactory.openSession()) {
            authsystems = session.createQuery("from Authsystem", Authsystem.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return authsystems;
    }

    @Override
    public void updateAuthsystem(Authsystem authsystem) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(authsystem);
            transaction.commit();
            System.out.println("Authsystem updated successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteAuthsystemById(int logid) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            Authsystem authsystem = session.get(Authsystem.class, logid);
            if (authsystem != null) {
                session.delete(authsystem);
                System.out.println("Authsystem deleted successfully!");
            } else {
                System.out.println("Authsystem not found with logid: " + logid);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Authsystem findByUsername(String username) {
        Authsystem authsystem = null;
        try (Session session = sessionFactory.openSession()) {
            authsystem = session.createQuery("from Authsystem where username = :username", Authsystem.class)
                    .setParameter("username", username)
                    .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return authsystem;
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
