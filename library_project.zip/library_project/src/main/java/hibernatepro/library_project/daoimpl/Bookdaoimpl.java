package hibernatepro.library_project.daoimpl;

import hibernatepro.library_project.dao.Bookdao;
import hibernatepro.library_project.entity.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Bookdaoimpl implements Bookdao {

    private SessionFactory sessionFactory;

    // Constructor to initialize SessionFactory
    public Bookdaoimpl() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Book.class).buildSessionFactory();
    }

    @Override
    public void saveBook(Book book) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(book);
            transaction.commit();
            System.out.println("Book saved successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Book getBookById(int id) {
        Book book = null;
        try (Session session = sessionFactory.openSession()) {
            book = session.get(Book.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return book;
    }

    @Override
    public List<Book> getAllBooks() {
        List<Book> books = null;
        try (Session session = sessionFactory.openSession()) {
            books = session.createQuery("from Book", Book.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    @Override
    public void updateBook(Book book) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(book);
            transaction.commit();
            System.out.println("Book updated successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteBookById(int id) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            Book book = session.get(Book.class, id);
            if (book != null) {
                session.delete(book);
                System.out.println("Book deleted successfully!");
            } else {
                System.out.println("Book not found with id: " + id);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

	@Override
	public List<Book> searchBooks(String searchQuery) {
		// TODO Auto-generated method stub
		return null;
	}
}
