package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.MemberReportdao;
import hibernatepro.library_project.daoimpl.MemberReportdaoimpl;
import hibernatepro.library_project.entity.MemberReport;

import java.util.List;

public class MemberReportservice {

    private MemberReportdao memberReportDao;

    // Constructor to initialize DAO
    public MemberReportservice() {
        memberReportDao = new MemberReportdaoimpl();
    }

    public void saveMemberReport(MemberReport memberReport) {
        memberReportDao.saveMemberReport(memberReport);
    }

    public MemberReport getMemberReportById(int id) {
        return memberReportDao.getMemberReportById(id);
    }

    public List<MemberReport> getAllMemberReports() {
        return memberReportDao.getAllMemberReports();
    }

    public void updateMemberReport(MemberReport memberReport) {
        memberReportDao.updateMemberReport(memberReport);
    }

    public void deleteMemberReportById(int id) {
        memberReportDao.deleteMemberReportById(id);
    }

    public void closeResources() {
        if (memberReportDao instanceof MemberReportdaoimpl) {
            ((MemberReportdaoimpl) memberReportDao).closeSessionFactory();
        }
    }

	public void generateReport(MemberReport report) {
		// TODO Auto-generated method stub
		
	}
}
