package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.Librariandao;
import hibernatepro.library_project.daoimpl.Librariandaoimpl;
import hibernatepro.library_project.entity.Librarian;

import java.util.List;

public class Librarianservice {

    private Librariandao librarianDao;

    // Constructor to initialize DAO
    public Librarianservice() {
        librarianDao = new Librariandaoimpl();
    }

    public void saveLibrarian(Librarian librarian) {
        librarianDao.saveLibrarian(librarian);
    }

    public Librarian getLibrarianById(int id) {
        return librarianDao.getLibrarianById(id);
    }

    public List<Librarian> getAllLibrarians() {
        return librarianDao.getAllLibrarians();
    }

    public void updateLibrarian(Librarian librarian) {
        librarianDao.updateLibrarian(librarian);
    }

    public void deleteLibrarianById(int id) {
        librarianDao.deleteLibrarianById(id);
    }

    public void closeResources() {
        if (librarianDao instanceof Librariandaoimpl) {
            ((Librariandaoimpl) librarianDao).closeSessionFactory();
        }
    }

	public void addLibrarian(Librarian librarian) {
		// TODO Auto-generated method stub
		
	}
}
