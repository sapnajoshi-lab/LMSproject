package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.Authsystemdao;
import hibernatepro.library_project.daoimpl.Authsystemdaoimpl;
import hibernatepro.library_project.entity.Authsystem;

import java.util.List;

public class Authsystemservice {

    private static Authsystemdao authsystemDao;

    // Constructor to initialize DAO
    public Authsystemservice() {
        authsystemDao = new Authsystemdaoimpl();
    }

    public void saveAuthsystem(Authsystem authsystem) {
        authsystemDao.saveAuthsystem(authsystem);
    }

    public Authsystem getAuthsystemById(int logid) {
        return authsystemDao.getAuthsystemById(logid);
    }

    public List<Authsystem> getAllAuthsystems() {
        return authsystemDao.getAllAuthsystems();
    }

    public void updateAuthsystem(Authsystem authsystem) {
        authsystemDao.updateAuthsystem(authsystem);
    }

    public void deleteAuthsystemById(int logid) {
        authsystemDao.deleteAuthsystemById(logid);
    }

    public static Authsystem findByUsername(String username) {
        return authsystemDao.findByUsername(username);
    }

    public void closeResources() {
        if (authsystemDao instanceof Authsystemdaoimpl) {
            ((Authsystemdaoimpl) authsystemDao).closeSessionFactory();
        }
    }
}
