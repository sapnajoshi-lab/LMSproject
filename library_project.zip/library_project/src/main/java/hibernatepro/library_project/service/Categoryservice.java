package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.Categorydao;
import hibernatepro.library_project.daoimpl.Categorydaoimpl;
import hibernatepro.library_project.entity.Category;

import java.util.List;

public class Categoryservice {

    private Categorydao categoryDao;

    // Constructor to initialize DAO
    public Categoryservice() {
        categoryDao = new Categorydaoimpl();
    }

    public void saveCategory(Category category) {
        categoryDao.saveCategory(category);
    }

    public Category getCategoryById(int id) {
        return categoryDao.getCategoryById(id);
    }

    public List<Category> getAllCategories() {
        return categoryDao.getAllCategories();
    }

    public void updateCategory(Category category) {
        categoryDao.updateCategory(category);
    }

    public void deleteCategoryById(int id) {
        categoryDao.deleteCategoryById(id);
    }

    public void closeResources() {
        if (categoryDao instanceof Categorydaoimpl) {
            ((Categorydaoimpl) categoryDao).closeSessionFactory();
        }
    }
}
